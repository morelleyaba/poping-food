   
<?php include("bd.php") ;
 ?>

<?php

function verifie($donnees){
 
   $donnees = (string) $donnees;
         if (isset($donnees) && !empty($donnees)) {
           return $donnees;
         }
         else {
           return false;
         }

 }

 // voir la valeur cotenu du post
 // var_dump($_POST);
 $answer=null;
if (!empty($_POST)) {
// $submit=$_POST['&submit'];
//    if ($submit=='send') {
     # code...
   
  
    $type_fournisseurs=isset($_POST['type_fournisseurs'])?$_POST['type_fournisseurs']:null;
  $service=isset($_POST['service'])?$_POST['service']:null;
  $product=isset($_POST['product'])?$_POST['product']:null;
  $message = '';

 if (verifie($type_fournisseurs) AND verifie($service) AND verifie($product)) {

   $answer= "ok1";


}else $answer="remplissez tous les champs svp!! ";

 // }else $answer="affaire de post!! ";
 }

$output=array('msg' =>$answer);

echo json_encode($output);
exit();

?>





