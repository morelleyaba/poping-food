<?php

 try{
 	$conn= new PDO("mysql:host=localhost; dbname=poping_food",'root','');
 }catch(PDOException $e){
 	die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 }
 



 ?>