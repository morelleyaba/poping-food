
 <?php
 include("bd.php");
// on se connecte à MySQL et on sélectionne la base


$answer= null;
$statut= false;
 // var_dump($_POST);
if (isset($_POST) and isset($_FILES['pictures']) and $_FILES['pictures']['error'] == 0)
{
  $message= ' ';
  $type_fournisseurs=isset($_POST['type_fournisseurs'])?$_POST['type_fournisseurs']:null;
  $service=isset($_POST['service'])?$_POST['service']:null;
  $product=isset($_POST['product'])?$_POST['product']:null;
  $pictures = $_FILES['pictures'];

   // renommer de l'image
  $newpicturesName= uniqid('std_att').time().'_'.rand(100,999);

  // traitements de l'image
     if ( $pictures['size']>=5000) {

   $autorised_extention=array('jpg','jpeg','png');

    $prepare_ext=explode('.', $pictures['name']);
     //La fonction explode () divise une chaîne en un tableau.
    $extention=array_pop($prepare_ext);
    //La fonction array_pop () selectionne la derniere valeur du tableau.
   $min_extention=strtolower($extention);
   if (in_array($min_extention, $autorised_extention)) {
     // 
    // 
     $statut=true; //ligne 8
     

   }else $answer='Le fichier importé n\'est pas une image';

  }
     else {

    $answer= 'l\'image selectionnée depasse la norme (5Mo Max)';
  }
                
   
                if ($statut===true) {

                //On créé la requête
                   $sql = 'INSERT INTO fournisseurs(type_fournisseurs,service,product,pictures) VALUES ("'.$type_fournisseurs.'","'.$service.'","'.$product.'","'.$newpicturesName.'")';


                 $result= $conn->query($sql);

              move_uploaded_file($pictures['tmp_name'], 'pictures/'.$newpicturesName. '.jpg');

              
              if (!$result) {

                $answer= "Query Failed";

              }else {
                $answer='ok';
              }

              }

}else $answer="veuillez ajouter ue image de description";

$output=array('msg2'=>$answer); 

echo json_encode($output);


?>