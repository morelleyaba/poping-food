<?php
	// var_dump($_SERVER);
include("bd.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<!-- Latest compiled and minified CSS -->
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>

	<nav>
	  <ul>
	    <li style="left:12px;top: 15px;margin-right: 100px;"><a href="#"  style="text-decoration: none"><img src="img/C.PNG"> &ensp;</a></li>
	    <li><a href="#" style="text-decoration: none">Accueil &ensp;</a></li>
	    <li><a href="#" style="text-decoration: none">Popping Food &ensp;</a></li>
	    <li><a href="#" style="text-decoration: none">Les Annonces</a></li>
	    <li><a href="#" style="text-decoration: none">Aide | Avis</a></li>
	    <li><a href="#" style="text-decoration: none">Se connecter |</a></li>
	    <li><a href="#" style="text-decoration: none">S’enregistrer</a></li>
	    <li class="deroulant"><SELECT name="lang" size="1">     
<OPTION>Fr
<OPTION>En           
</SELECT>
	    </li>
	  </ul>
	</nav>

<!-- ************************************************************************************** -->

<section style="margin-left:-120px;margin-right:590%;width: 100%;height: 250px;">
<div class="container">
    <div class="row">
        <div class="col-md-12"><img src="img/d.PNG"></div>
    	</div>
    
    </div>

</section>

<!-- ************************************************************************** -->
<!-- ************************************************************************** -->

<section>
	     
    <div class="row">
        <div class="container">

</div>
</div>
</section>

<!-- ************************************************************************************** -->
<section class="pt-5 mb-5">
	<div class="container">
		<div class="row">
        <div class="col-sm-6" style="border: 12px;border-color: black;">
        	<h2 style="color: green;">Je suis demandeur</h2>
        	<a href="demandeurs.php" style="margin-left: 82px;padding: 22px;color: white;background-color: green;text-decoration: none;padding-top: 8px;">cliquez-ici</a>
        	<!-- <button class="btn btn-primary" style="margin-left: 82px;">cliquez-ici</button> -->
        </div>
        <div class="col-sm-6 a">
        	<h2 style="color: orange;">Je suis fournisseur</h2>
        	<a href="fournisseurs.php" style="margin-left: 82px;padding: 22px;color: black;background-color: orange;text-decoration: none;padding-top: 8px;">cliquez-ici</a>
        	<!-- <input type="text" name="" value="cliquez-ici" style="margin-left: 82px;padding-right: 22px;padding-left: 22px;color: black;background-color: orange;"> -->
        </div>
    </div>
	</div>
</section>



















	<!-- <div class="conteneur">
	  <p>Du contenu sous le menu</p>
	</div> -->




	<!-- <li class="deroulant"><a href="#">Popping Food &ensp;</a>
	      <ul class="sous">
	        <li><a href="#">CSS display</a></li>
	        <li><a href="#">CSS position</a></li>
	        <li><a href="#">CSS float</a></li>
	      </ul>
	    </li> -->
</body>
</html>