<?php session_start(); ?>
<!DOCTYPE html>
<html>
<title>rien</title>
<head>
</head>
<body>

    
<form action="" method="post" id="test">
        <input type="text" name="email"/>
        <button type="submit" name="send_form" value="send">Add To Databse</button>
        <button type="submit" name="send_form" value="save">Save</button>
    </form>



</body>
<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script>
    $('button').on('click', function (e) {
  $.ajax({
    type: 'post',
    url: 'action.php',
    data: $("#test").serialize() + '&submit='+ $(this).attr("value"),
    success: function (res) {
      location.reload();
    }
    error: function () {
        alert("Erreur d'envoi de donnée");
      }
  });
  e.preventDefault();
});
</script>
</html>