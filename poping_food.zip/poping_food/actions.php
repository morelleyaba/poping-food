<?php 

}



$_POST= Array
(
    'email' => 'me@me.com'
    'submit' => 'send'
)

$_POST= Array
(
    'email' => 'me@me.com'
    'submit' => 'save'
)
 ?>