


<?php include("inc/header.php") ?><br><br>


<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-4 col-md-offset-4">
            <div class="note">
                    <p>Se connecter</p>
                </div>
            <div class="account-wall">
                <div id="message"></div>
                <form class="form-signin" id="form_login">
                    

                <input type="email" class="form-control" name="email" placeholder="Email" required autofocus>
                <br>
                <input type="Mot de Passe" class="form-control" placeholder="Mot de Passe" name="motpasse" required>
                <br>
                <button class="btn btn-lg btn-primary btn-block" type="submit">
                    Se connecter</button>
                <label class="checkbox pull-left">
                    <input type="checkbox" value="remember-me">
                    Remember me
                </label>
                <a href="#" class="pull-right need-help">Need help? </a><span class="clearfix"></span>
                </form>
            </div>
            <a href="register_prof.php" class="text-center new-account">Creer un compte </a>
        </div>
    </div>
</div>


<?php include("inc/footer.php") ?>