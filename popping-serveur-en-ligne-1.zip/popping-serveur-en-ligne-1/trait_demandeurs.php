   
<?php

function verifie($donnees){
 
   $donnees = (string) $donnees;
         if (isset($donnees) && !empty($donnees)) {
           return $donnees;
         }
         else {
           return false;
         }

 }

$answer=null;

if (isset($_POST)) {

    include("bd.php") ;
  
    $type_demandeurs=isset($_POST['type_demandeurs'])?$_POST['type_demandeurs']:null;
  
  $product = isset($_POST['product'])?$_POST['product']:null;
  $experience = isset($_POST['experience'])?$_POST['experience']:null;
  $language = isset($_POST['language'])?$_POST['language']:null;
  $beneficiaires = isset($_POST['beneficiaires'])?$_POST['beneficiaires']:null;

  $checkbox1 = isset($_POST['service'])?$_POST['service']:null;
  $message = '';

 if (verifie($type_demandeurs) AND verifie($product) AND verifie($experience) AND verifie($language)AND verifie($beneficiaires)AND !empty($checkbox1)) {
// ***********
  $chk="";  
foreach($checkbox1 as $chk1)  
   {  
      $chk .= $chk1."/";  
   }  

  $sql = 'INSERT INTO demandeurs(type_demandeurs,product,experience,language,beneficiaires,service) VALUES ("'.$type_demandeurs.'","'.$product.'","'.$experience.'","'.$language.'","'.$beneficiaires.'","'.$chk.'")';

                 $result= $conn->query($sql);
    if (!$result) {

                $answer= "Query Failed";

              }else {
                $answer='ok';
              }
}else $answer="remplissez tous les champs svp!! ";

 }

$output=array('msg' =>$answer);

echo json_encode($output);

?>