<?php include("inc/header.php") ?>

<section>  
            <!-- Fisrt title -->
            
                <section class="title">
                    
                    <h1 id="principal-title">SERVICE DE DEPÔT ET MISE EN RELATION</h1><br>
                    <h2 id="second-title">Complétez les filtres pour accéder au liste de fournisseurs correspondant à votre rechercheé</h2>

 <br>
                </section>

<div class="container shadow col-md-9" style="padding-bottom: 1px;padding-top: 1px;background-color: white" >
<br>
            <form  id="form-depot" method="POST">
                

                <div class="form-group mb-4">
                   <h3 for="" style="">1- Qui êtes vous ?
                                <span>(seul 1 critère peut être sélectionné)</span></h3><br>
                <SELECT name="type_fournisseurs" size="1">
<OPTION>          
<OPTION>Petite entreprise agroalimentaire
<OPTION>Moyenne entreprise agroalimentaire
    <OPTION>Start-up en agroalimentaire
        <OPTION>Tout particulier voulant entreprendre en agroalimentaire
            
</SELECT>
                </div>
            
            <h3>2- Quels services souhaités vous ?</h3>

                            <div>
                                <label>
                                <input type="radio" name="service" value="Prêt ou microfinancement en agroalimentaire"> <span> Prêt ou microfinancement en agroalimentaire </span></label> <br>
                                
                                <label><input type="radio" name="service" value="Coaching (en agro-marketing & agribusiness) et accélérateurs/incubateurs"> <span> Coaching (en agro-marketing & agribusiness) et accélérateurs/incubateurs</span> </label><br>
                                
                                <label><input type="radio" name="service" value="Formation en agroalimentaire : conservation-stockage, transformation des
                                aliments, emballages alimentaires, analyse qualité"> <span> Formation en agroalimentaire : conservation-stockage, transformation des
                                aliments, emballages alimentaires, analyse qualité</span></label> <br>

                                <label><input type="radio" name="service" value="Formation sur le dimensionnement d’une unité agroalimentaire, conception
                                du plan respectant les normes "> <span> Formation sur le dimensionnement d’une unité agroalimentaire, conception
                                du plan respectant les normes </span></label> <br>
                                
                                <label><input type="radio" name="service" value="Formation en formulation d’aliments mixte nutritionnels avec produits locaux"> <span> Formation en formulation d’aliments mixte nutritionnels avec produits locaux</span></label> <br>

                                <label><input type="radio" name="service" value="Formation en valorisation des sous-produits agroalimentaires "> <span> Formation en valorisation des sous-produits agroalimentaires </span></label> <br>

                                <label><input type="radio" name="service" value="Acquisition de matériels/d’équipements, d’ emballages en agroalimentaire
                                « classique » "> <span> Acquisition de matériels/d’équipements, d’ emballages en agroalimentaire
                                « classique » </span></label> <br>

                                <label><input type="radio" name="service" value="Acquisition de matériels/d’équipements, d’ emballages en agroalimentaire
                                « eco-friendly »"> <span> Acquisition de matériels/d’équipements, d’ emballages en agroalimentaire
                                « eco-friendly »</span></label> <br>

                                <label><input type="radio" name="service" value="Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle "> <span> Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle </span></label> <br>

                                <label><input type="radio" name="service" value="Maintenance de matériels/d’équipements en agroalimentaire "> <span> Maintenance de matériels/d’équipements en agroalimentaire </span></label> <br>

                                <label><input type="radio" name="service" value="Installation d’unité aux normes agroalimentaire "> <span> Installation d’unité aux normes agroalimentaire </span> </label><br>

                                
                 
                           </div>  
                <div class="form-group mb-4">
                   <h3 for="" style="">3- Quels produits alimentaires souhaités</h3><br>
                <SELECT name="product" size="1" style="width: 40%; margin-left: 3%">
<OPTION>          
<OPTION>Tubercules/racines
<OPTION>Légumes
    <OPTION>Feuilles vertes
        <OPTION>Laits/produits laitiers
            <OPTION>Légumineuses
                <OPTION> Poissons/fruits de mer
                    <OPTION> Epices
                        <OPTION> Tous les produits
            
</SELECT>

                </div>
<br>
                <div id="message" style="text-align: center"></div>
 <div class="row  mb-5"> 
                 
                           <div id="form-footer" class="flex-row-arround">
                            <input type="submit" name="register" value="Enregistrez">
                            <input type="" name="search" value="Recherchez">
                        </div>
<a href="demandeurs.php" style="font-size: 0.9em; color: gray; margin-left: 5%;">Formulaire des demandeurs</a>
                </div>

                 

            </form>
        
    </div>
<br><br>
</section>

<?php include("inc/footer.php") ?>





