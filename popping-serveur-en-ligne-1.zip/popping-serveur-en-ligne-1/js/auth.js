

      $(document).ready(function(){
	$("#form-depot").on("submit", function(e){
		
		e.preventDefault();
		var form = $("#form-depot");

		$.ajax({

           method: "POST",
           url:"trait_fournisseurs.php",
           dataType:"JSON",
           data: form.serialize(),
           success: function(reponse)
           {
           	if (reponse.msg=='ok') {
             
        $("#message").removeClass("alert-danger").addClass("alert alert-success").html('l\'enregistrement a été effectué avec succes!!');
             $("#form-depot").trigger('reset');
             
           	
           	} else{

                 $('#message').addClass("alert alert-danger").html(reponse.msg);

           	}
           },

           error: function () {
				alert("Erreur d'envoi de donnée");
			}
		})
	});
})


      $(document).ready(function(){
  $("#form-ask").on("submit", function(e){
    
    e.preventDefault();
    var form = $("#form-ask");

    $.ajax({

           method: "POST",
           url:"trait_demandeurs.php",
           dataType:"JSON",
           data: form.serialize(),
           success: function(reponse)
           {
            if (reponse.msg=='ok') {
             
        $("#message").removeClass("alert-danger").addClass("alert alert-success").html('l\'enregistrement a été effectué avec succes!!');
             $("#form-ask").trigger('reset');
            

            
            } else{

                 $('#message').addClass("alert alert-danger").html(reponse.msg);

                 
            }
           },

           error: function () {
        alert("Erreur d'envoi de donnée");
      }
    })
  });
})
