-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 16 jan. 2021 à 15:18
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `poping_food`
--

-- --------------------------------------------------------

--
-- Structure de la table `demandeurs`
--

CREATE TABLE `demandeurs` (
  `id_demandeurs` int(11) NOT NULL,
  `type_demandeurs` varchar(200) NOT NULL,
  `product` varchar(200) NOT NULL,
  `experience` varchar(500) NOT NULL,
  `language` varchar(200) NOT NULL,
  `beneficiaires` varchar(200) NOT NULL,
  `service` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `demandeurs`
--

INSERT INTO `demandeurs` (`id_demandeurs`, `type_demandeurs`, `product`, `experience`, `language`, `beneficiaires`, `service`) VALUES
(1, 'Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)', 'Poissons/fruits de mer', '5-10 ans ', 'Espagnol', 'Start-up en agroalimentaire', 'Constitution dossier_Formations en agroalimentaire sur l’emballage-conditionnement- étiquetage_Equipements manuels et légers de transformation, conservation, emballage_'),
(2, 'Commerciaux IAA (particulier, PME/start-up fabricants, revendeurS, distributeurs d’équipements agroalimentaire)', 'Epices', '0-5 ans', 'Anglais', 'Start-up en agroalimentaire', 'Formations en agroalimentaire sur la conservation/transformation (techniques de conservation, bonnes pratiques de transformation et d’hygiène, sur HAACP/Transformation par des techniques améliorées adaptées (eco-friendly) /Equipements semi-industriels de transformation, conservation, emballage/');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseurs`
--

CREATE TABLE `fournisseurs` (
  `id_fournisseurs` int(11) NOT NULL,
  `type_fournisseurs` varchar(200) NOT NULL,
  `service` varchar(200) NOT NULL,
  `product` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `fournisseurs`
--

INSERT INTO `fournisseurs` (`id_fournisseurs`, `type_fournisseurs`, `service`, `product`) VALUES
(1, 'Start-up en agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Laits/produits laitiers');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `demandeurs`
--
ALTER TABLE `demandeurs`
  ADD PRIMARY KEY (`id_demandeurs`);

--
-- Index pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  ADD PRIMARY KEY (`id_fournisseurs`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `demandeurs`
--
ALTER TABLE `demandeurs`
  MODIFY `id_demandeurs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  MODIFY `id_fournisseurs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
