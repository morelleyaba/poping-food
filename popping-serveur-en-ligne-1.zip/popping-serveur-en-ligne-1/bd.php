<?php
// include("createdatabase.php");

 try{
 	$conn= new PDO("mysql:host=localhost; dbname=u354647590_poppingfood",'u354647590_TetchiSA','Simpl@n2252019');
 }catch(PDOException $e){
 	die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 } 
 



 ?>
