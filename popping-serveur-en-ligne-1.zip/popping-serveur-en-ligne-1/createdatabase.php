
<?php
 $servername = "localhost";
 $username = "u354647590_TetchiSA";
 $password = "Simpl@n2252019";
 $dbname = "u354647590_poppingfood";
 // Create connection
 
$link = mysqli_connect($servername, $username, $password, $dbname);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt create table query execution
$sql = "CREATE TABLE demandeurs(
    id_demandeurs INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    type_demandeurs VARCHAR(200) NOT NULL,
    product VARCHAR(200) NOT NULL,
    experience TEXT NOT NULL,
    language VARCHAR(200) NOT NULL,
    beneficiaires VARCHAR(200) NOT NULL,
    service TEXT NOT NULL
)";
if(mysqli_query($link, $sql)){
    echo "Table created successfully cool.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

$query = "CREATE TABLE fournisseurs(
    id_fournisseurs INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    type_fournisseurs VARCHAR(200) NOT NULL,
    service VARCHAR(200) NOT NULL,
    product VARCHAR(200) NOT NULL
)";
if(mysqli_query($link, $query)){
    echo "Table creée avec success.";
} else{
    echo "ERROR: fournisseur n'a pa pu etre creeé $query. " . mysqli_error($link);
}
 
 
// Close connection
mysqli_close($link);
?>
