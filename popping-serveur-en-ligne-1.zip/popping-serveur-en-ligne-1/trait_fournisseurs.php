
<?php
include("bd.php") ;
function verifie($donnees){
 
   $donnees = (string) $donnees;
         if (isset($donnees) && !empty($donnees)) {
           return $donnees;
         }
         else {
           return false;
         }

 }

 $answer=null;
if (isset($_POST)) {

    
  
    $type_fournisseurs=isset($_POST['type_fournisseurs'])?$_POST['type_fournisseurs']:null;
  $service=isset($_POST['service'])?$_POST['service']:null;
  $product=isset($_POST['product'])?$_POST['product']:null;
  $message = '';

 if (verifie($type_fournisseurs) AND verifie($service) AND verifie($product)) {
  $sql = 'INSERT INTO fournisseurs(type_fournisseurs,service,product) VALUES ("'.$type_fournisseurs.'","'.$service.'","'.$product.'")';

                 $result= $conn->query($sql);
    if (!$result) {

                $answer= "Query Failed";

              }else {
                $answer='ok';
              }
}else $answer="remplissez tous les champs svp!! ";

 }

$output=array('msg' =>$answer);

echo json_encode($output);

?>