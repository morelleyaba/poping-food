
 
<?php
// fichier permettant de se connecter a la base de donnée et d'apporter des modifications sur les differentes tables du serveur local
$servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "poping_food";

$link = mysqli_connect($servername, $username, $password, $dbname);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


$query = "DROP TABLE IF EXISTS fournisseurs";
if(mysqli_query($link, $query)){
    echo "Table suprimé.";
} else{
    echo "ERROR: fournisseurs n'a pas pu etre supprimé $query. " . mysqli_error($link);
}
 
mysqli_close($link);


 ?>