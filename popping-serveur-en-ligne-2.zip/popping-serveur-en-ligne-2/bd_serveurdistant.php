 <?php
// include("createdatabase.php");
 // file used for connection to serveur distant
// delete prefix ('serveurdistant_' after 'bd.php') in oder to send online 
 // bd_serveurdistant.php ==>become 'bd.php'

 try{
 	$conn= new PDO("mysql:host=localhost; dbname=u354647590_poppingfood",'u354647590_TetchiSA','Simpl@n2252019');
 }catch(PDOException $e){
 	die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 } 
 



 ?>


