<?php include("inc/header.php") ?>
    <!-- Main -->
        <main>
            
            <!-- Fisrt title -->
            
                <section class="title">
                    
                     <h1 id="principal-title">SERVICE DE DEPÔT ET MISE EN RELATION</h1>
                     <br>
                    <h2 id="second-title">Complétez les filtres pour accéder à la soumission de votre offre et la liste de demandeurs correspondant à votre recherche</h2>

                </section>

            <!-- # Fisrt title -->
            


            <!-- Form -->
            
                <section class="section-form-demandeurs flex-column-arround" >
                    
                    <form id="form-ask" class="flex-column-arround form-depot-demandeurs">


                        <!-- Section content with flex-row -->
                            <section class="flex-row-arround" style="align-items: flex-start;">
                                

                                <!-- Column 1 -->
                                    <div class="form-part-1">
                                    
                                        <h3>1- Qui êtes vous ?<br>
                                            <span>(seul 1 critère peut être sélectionné)</span></h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="type_demandeurs" value="Prêteurs (institution de microfinancement)"> <span> Prêteurs (institution de microfinancement)</span></label> <br>
                                            
                                            <label><input type="radio" name="type_demandeurs" value="Coach (accélérateurs, incubateurs) en agroalimentaire, agribusiness, agro-marketing "> <span>Coach (accélérateurs, incubateurs) en agroalimentaire, agribusiness, agro-marketing </span></label> <br>

                                            <label><input type="radio" name="type_demandeurs" value="Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)"> <span> Consultants IAA (formateur en agroalimentaires, nutrition et agrovalorisation)</span></label> <br>

                                            <label><input type="radio" name="type_demandeurs" value="Commerciaux IAA (particulier, PME/start-up fabricants, revendeurS, distributeurs d’équipements agroalimentaire)"> <span> Commerciaux IAA (particulier, PME/start-up fabricants, revendeurs, distributeurs d’équipements agroalimentaire)</span></label> <br>
                                            
                                        </div>

<h3 class="pt-5">2- Quels sont les bénéficiaires cibles de la prestation<br>
                                            <span>(cocher que les champs rentrant dans votre spécialisation et expertise) ?</span></h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="beneficiaires" value="Petite entreprise agroalimentaire"> <span> Petite entreprise agroalimentaire</span></label> <br>
                                            <label><input type="radio" name="beneficiaires" value="Moyenne entreprise agroalimentaire"> <span> Moyenne entreprise agroalimentaire</span> </label><br>
                                            <label><input type="radio" name="beneficiaires" value="Start-up en agroalimentaire"> <span> Start-up en agroalimentaire</span></label> <br>
                                            <label><input type="radio" name="beneficiaires" value="Petite entreprise agroalimentaire"> <span> Tout particulier voulant entreprendre en agroalimentaire</span></label> <br>
                                        </div>

                                        <h3 class="pt-4">3- Quels produits alimentaires souhaités ? <br>
                                            <span>(cocher que les champs rentrant dans votre spécialisation et expertise)</span></h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="product" value="Tubercules/racines"> <span> Tubercules/racines</span></label> <br>
                                             <label><input type="radio" name="product" value="Fruits "> <span> Fruits </span></label> <br>
                                             <label><input type="radio" name="product" value="Légumes"> <span> Légumes</span></label> <br>
                                             <label><input type="radio" name="product" value="Feuilles vertes"> <span> Feuilles vertes</span> </label><br>
                                             <label><input type="radio" name="product" value="Laits/produits laitiers"> <span> Laits/produits laitiers</span></label> <br>
                                             <label><input type="radio" name="product" value="Viandes/produits carnés "> <span> Viandes/produits carnés </span></label> <br>
                                             <label><input type="radio" name="product" value="Légumineuses "> <span> Légumineuses </span></label> <br>
                                             <label><input type="radio" name="product" value="Oléagineuses"> <span> Oléagineuses</span></label> <br>
                                             <label><input type="radio" name="product" value="Poissons/fruits de mer"> <span> Poissons/fruits de mer</span> </label><br>
                                             <label><input type="radio" name="product" value="Epices"> <span> Epices</span> </label><br>
                                             <label><input type="radio" name="product" value="Tous les produits"> <span>Tous les produits</span></label> <br>
                                            
                                        </div>



                                        <h3 class="pt-5">4- Quelle année d’expériences dans le secteur agricole et agroalimentaire des PED par l’acteur fournisseur?</h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="experience" value="0-5 ans"> <span> 0-5 ans </span></label> <br>
                                            <label><input type="radio" name="experience" value="5-10 ans "> <span> 5-10 ans </span></label> <br>
                                            <label><input type="radio" name="experience" value="+15 ans "> <span> +15 ans </span> </label><br>
                                            
                                        </div>





                                        <!-- <h3 class="pt-5">6- Langue parlée par l’acteur Fournisseurs / Demandeurs</h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="language" value="Français"> <span> Français </span> </label><br>
                                            <label><input type="radio" name="language" value="Anglais"> <span> Anglais </span></label> <br>
                                            <label><input type="radio" name="language" value="Arabe"> <span> Arabe </span></label> <br>
                                            <label><input type="radio" name="language" value="Portugais"> <span> Portugais </span></label> <br>
                                            <label><input type="radio" name="language" value="Espagnol"> <span> Espagnol </span></label> <br>
                                            
                                        </div>

 -->

                                    </div>
                                <!-- # Column 2 -->


                                <!-- Column 2 -->
                                    <div class="form-part-2">
                                    

                                        <!-- ---------- -->
                                        <!-- <h3>2- Quels sont les bénéficiaires cibles de la prestation<br>
                                            <span>(cocher que les champs rentrant dans votre spécialisation et expertise) ?</span></h3>

                                        <div>
                                            <label>
                                            <input type="radio" name="beneficiaires" value="Petite entreprise agroalimentaire"> <span> Petite entreprise agroalimentaire</span></label> <br>
                                            <label><input type="radio" name="beneficiaires" value="Moyenne entreprise agroalimentaire"> <span> Moyenne entreprise agroalimentaire</span> </label><br>
                                            <label><input type="radio" name="beneficiaires" value="Start-up en agroalimentaire"> <span> Start-up en agroalimentaire</span></label> <br>
                                            <label><input type="radio" name="beneficiaires" value="Petite entreprise agroalimentaire"> <span> Tout particulier voulant entreprendre en agroalimentaire</span></label> <br>
                                        </div> -->
                                        <!-- ---------- -->
                                        



                                        <!-- 4- Quels services proposez-vous ? -->

                                            <h3 class="">5- Quels services proposez-vous ?</h3>

                                            <div>
                                                
                                                <!-- ---------- -->
                                                <!-- <input type="radio" name="expertise-formation-agroalimentaire" value="Prêt ou microfinancement en agroalimentaire "> --> <span>Prêt ou microfinancement en agroalimentaire </span> <br> <span style="font-size: 0.5em; margin-left: 25px;">(cocher que les champs très spécifiques à votre domaine d’expertise)</span><br>

                                                <div class="checkbox-form-part2" style="margin-bottom: 20px;">
                                                    <label><input type="checkbox" name="service[]" value="Prêt à taux réduit">Prêt à taux réduit</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="Condition de remboursement simple ">Condition de remboursement simple </input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="Constitution dossier">Tout particulier voulant entreprendre en agroalimentaire</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="Prêt à taux réduit">Autres service avantageux offerts </input></label><br>
                                                </div>
                                                <!-- ---------- -->



                                                <!-- ---------- -->
                                                <!-- <input type="radio" name="expertise-formation-agroalimentaire" value="Coaching et accompagnement (par accélérateur ou incubateur) en agroalimentaire"> --> <span>Coaching et accompagnement (par accélérateur ou incubateur) en agroalimentaire</span> <br> <span style="font-size: 0.5em; margin-left: 25px;">(cocher que les champs très spécifiques à votre domaine d’expertise) </span><br>

                                                <div class="checkbox-form-part2" style="margin-bottom: 20px;">
                                                    <label><input type="checkbox" name="service[]" value="En agribusiness">En agribusiness</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="En agromarketing">En agromarketing</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="En recherche de financement ">En recherche de financement </input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="En rédaction de business plan">En rédaction de business plan</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="Offre de domiciliation d’entreprise">Offre de domiciliation d’entreprise</input></label><br>
                                                    <label><input type="checkbox" name="service[]" value="Offre d’incubation">Offre d’incubation</input></label><br>
                                                </div>
                                                <!-- ---------- -->



                                                <!-- ---------- -->
                                                <!-- <input type="radio" name="expertise-formation-agroalimentaire" value="Expertise en formation en agroalimentaire"> --> <span>Expertise en formation en agroalimentaire</span> <br> <span style="font-size: 0.5em; margin-left: 25px;">(cocher que les champs très spécifiques à votre domaine d’expertise) </span><br>
                                                

                                                <div class="checkbox-form-part2" style="margin-bottom: 20px;">

                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formations en agroalimentaire sur la conservation/transformation (techniques de conservation, bonnes pratiques de transformation et d’hygiène, sur HAACP">Formations en agroalimentaire sur la conservation/transformation (techniques de conservation, bonnes pratiques de transformation et d’hygiène, sur HAACP</input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formations en agroalimentaire sur l’emballage-conditionnement- étiquetage">Formations en agroalimentaire sur l’emballage-conditionnement- étiquetage</input></label><br>

                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur le dimensionnement d’une unité agroalimentaire, conception du plan respectant les normes">Formation sur le dimensionnement d’une unité agroalimentaire, conception du plan respectant les normes</input></label><br>

                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formations en agroalimentaire sur transformation sensible au climat">Formations en agroalimentaire sur transformation sensible au climat</input></label><br>

                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Transformation par des techniques améliorées adaptées (eco-friendly) ">Transformation par des techniques améliorées adaptées (eco-friendly) </input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur l’agro-transformation sensible au genre (simple/facile d’utilisation, utilisant des techniques réduisant la pénibilité et le temps de travail) ">Formation sur l’agro-transformation sensible au genre (simple/facile d’utilisation, utilisant des techniques réduisant la pénibilité et le temps de travail) </input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur l’agro-transformation sensible à la nutrition : formulation de produits nutritionnels ">Formation sur l’agro-transformation sensible à la nutrition : formulation de produits nutritionnels </input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur la sécurité sanitaire des aliments">Formation sur la sécurité sanitaire des aliments</input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur le contrôle qualité des aliments et sur l’analyse aulaboratoire des aliments,">Formation sur le contrôle qualité des aliments et sur l’analyse au laboratoire des aliments,</input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation sur la certification aux normes internationales de Qualité">Formation sur la certification aux normes internationales de Qualité</input></label><br>
                                                    
                                                    <!-- ----- -->
                                                    <label><input type="checkbox" name="service[]" value="Formation en valorisation des sous-produits agroalimentaires">Formation en valorisation des sous-produits agroalimentaires</input></label><br>
                                                    
                                                    
                                                </div>
                                                <!-- ---------- -->



                                                <!-- ---------- -->
                                                <!-- <input type="radio" name="expertise-formation-agroalimentaire" value="Expertise en formation en agroalimentaire"> --> <span>Fourniture de matériels/d’équipements en agroalimentaire : Equipements neufs/reconditionnés</span><br>


                                                <div class="checkbox-form-part2" style="margin-bottom: 20px;">
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements manuels et légers de transformation, conservation, emballage">Equipements manuels et légers de transformation, conservation, emballage</input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements semi-industriels de transformation, conservation, emballage">Equipements semi-industriels de transformation, conservation, emballage</input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements eco-friendly pour la transformation, conservation, emballage">Equipements eco-friendly pour la transformation, conservation, emballage</input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements de d’analyse et contrôle qualité ">Equipements de d’analyse et contrôle qualité </input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements d’information et d’accès sur le marché agroalimentaire ">Equipements d’information et d’accès sur le marché agroalimentaire </input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Equipements conçus à la demande selon les spécifications du client">Equipements conçus à la demande selon les spécifications du client</input></label><br>
                                                    
                                                    <!-- ---------- -->
                                                    <label><input type="checkbox" name="service[]" value="Unités de transformation agroalimentaire miniaturisée fonctionnelles">Unités de transformation agroalimentaire miniaturisée fonctionnelles</input></label><br>

                                                </div>
                                                <!-- ---------- -->

<div class="form-group pt-4 mb-4">
                   <h3 for="" style="">6- Langue parlée par l’acteur Fournisseurs / Demandeurs</h3><br>
                <SELECT name="language" size="1" style="width: 50%; margin-left: 3%">
<OPTION>          
<OPTION>Français
<OPTION>Anglais
    <OPTION> Arabe
        <OPTION>Espagnol
            <OPTION>Espagnol
            
</SELECT>
                </div>
                                            <!-- # 4- Quels services proposez-vous ? -->


                                        </div>


                                    </div>
                                <!-- # Column 2 -->


                            </section>
                        <!-- # Section content with flex-row -->
                        
<br>
                    <div id="message" style="text-align: center;margin-left: 30%"></div><br>
                        <div id="form-footer" class="flex-row-arround">

                            <input type="submit" name="register" value="Enregistrez">
                            <input type="" name="search" value="Recherchez">
                        </div>

                        <a href="fournisseurs.php" style="font-size: 0.9em; color: gray; margin-left: 5%;">Formulaire des fournisseurs</a>

                    </form>

                </section>
            
            <!-- # Form -->



        </main>

<?php include("inc/footer.php") ?>