-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 29 jan. 2021 à 11:28
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `poping_food`
--

-- --------------------------------------------------------

--
-- Structure de la table `demandeurs`
--

CREATE TABLE `demandeurs` (
  `id_demandeurs` int(11) NOT NULL,
  `type_demandeurs` varchar(200) NOT NULL,
  `product` varchar(200) NOT NULL,
  `experience` varchar(500) NOT NULL,
  `language` varchar(200) NOT NULL,
  `beneficiaires` varchar(200) NOT NULL,
  `service` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `demandeurs`
--

INSERT INTO `demandeurs` (`id_demandeurs`, `type_demandeurs`, `product`, `experience`, `language`, `beneficiaires`, `service`) VALUES
(1, 'Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)', 'Poissons/fruits de mer', '5-10 ans ', 'Espagnol', 'Start-up en agroalimentaire', 'Constitution dossier_Formations en agroalimentaire sur l’emballage-conditionnement- étiquetage_Equipements manuels et légers de transformation, conservation, emballage_'),
(2, 'Commerciaux IAA (particulier, PME/start-up fabricants, revendeurS, distributeurs d’équipements agroalimentaire)', 'Epices', '0-5 ans', 'Anglais', 'Start-up en agroalimentaire', 'Formations en agroalimentaire sur la conservation/transformation (techniques de conservation, bonnes pratiques de transformation et d’hygiène, sur HAACP/Transformation par des techniques améliorées adaptées (eco-friendly) /Equipements semi-industriels de transformation, conservation, emballage/'),
(3, 'Coach (accélérateurs, incubateurs) en agroalimentaire, agribusiness, agro-marketing ', 'Tous les produits', '5-10 ans ', 'Arabe', 'Start-up en agroalimentaire', 'Equipements semi-industriels de transformation, conservation, emballage/'),
(4, 'Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)', 'Poissons/fruits de mer', '5-10 ans ', 'Anglais', 'Start-up en agroalimentaire', 'Prêt à taux réduit/En rédaction de business plan/Formations en agroalimentaire sur l’emballage-conditionnement- étiquetage/Unités de transformation agroalimentaire miniaturisée fonctionnelles/'),
(5, 'Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)', 'Poissons/fruits de mer', '5-10 ans ', 'Arabe', 'Moyenne entreprise agroalimentaire', 'En rédaction de business plan/Formation sur le contrôle qualité des aliments et sur l’analyse aulaboratoire des aliments,/'),
(6, 'Consultants IAA (formateur en agroalimentaires, nutritionet agrovalorisation)', 'Poissons/fruits de mer', '0-5 ans', 'Arabe', 'Petite entreprise agroalimentaire', 'Constitution dossier/Equipements conçus à la demande selon les spécifications du client/');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseurs`
--

CREATE TABLE `fournisseurs` (
  `id_fournisseurs` int(11) NOT NULL,
  `type_fournisseurs` varchar(200) NOT NULL,
  `service` varchar(200) NOT NULL,
  `product` varchar(200) NOT NULL,
  `pictures` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `fournisseurs`
--

INSERT INTO `fournisseurs` (`id_fournisseurs`, `type_fournisseurs`, `service`, `product`, `pictures`) VALUES
(1, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Feuilles vertes', 'std_att6010bbf6a29ab1611709430_776'),
(2, 'Start-up en agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Feuilles vertes', 'std_att6010bcb7be4401611709623_244'),
(3, 'Moyenne entreprise agroalimentaire', 'Installation d’unité aux normes agroalimentaire ', 'Tubercules/racines', 'std_att6010c0a8a601f1611710632_648'),
(4, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Laits/produits laitiers', 'std_att6010c0f912bb51611710713_597'),
(5, 'Start-up en agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Laits/produits laitiers', 'std_att6010c2d01d3bd1611711184_142'),
(6, 'Start-up en agroalimentaire', 'Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle ', 'Feuilles vertes', 'std_att6010c3548d7571611711316_792'),
(7, 'Moyenne entreprise agroalimentaire', 'Installation d’unité aux normes agroalimentaire ', 'Poissons/fruits de mer', 'std_att6010c493020561611711635_767'),
(8, 'Start-up en agroalimentaire', 'Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle ', 'Laits/produits laitiers', 'std_att6010c4b1a68be1611711665_651'),
(9, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Laits/produits laitiers', 'std_att6010c585c00d41611711877_876'),
(10, 'Start-up en agroalimentaire', 'Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle ', 'Laits/produits laitiers', 'std_att6010c7264ec271611712294_773'),
(11, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Laits/produits laitiers', 'std_att60112f217685f1611738913_570'),
(12, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Feuilles vertes', 'std_att601130f08195f1611739376_330'),
(13, 'Petite entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Tubercules/racines', 'std_att6011316754d2c1611739495_401'),
(14, 'Petite entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Tubercules/racines', 'std_att60113167566311611739495_841'),
(15, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Feuilles vertes', 'std_att60113237eb18c1611739703_146'),
(16, 'Tout particulier voulant entreprendre en agroalimentaire', 'Formation en valorisation des sous-produits agroalimentaires ', 'Laits/produits laitiers', 'std_att601132afe97751611739823_428'),
(17, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Légumineuses', 'std_att6011b465399d61611773029_416'),
(18, 'Moyenne entreprise agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Feuilles vertes', 'std_att6011b4d1c88651611773137_422'),
(19, 'Start-up en agroalimentaire', 'Maintenance de matériels/d’équipements en agroalimentaire ', 'Légumineuses', 'std_att6012e7f93c4a11611851769_810'),
(20, 'Start-up en agroalimentaire', 'Acquisition d’unité de transformation agroalimentaire miniaturisée fonctionnelle ', 'Feuilles vertes', 'std_att6013e1e71a3e21611915751_319'),
(21, 'Tout particulier voulant entreprendre en agroalimentaire', 'Prêt ou microfinancement en agroalimentaire', 'Laits/produits laitiers', 'std_att6013e2f59c6c11611916021_213');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `demandeurs`
--
ALTER TABLE `demandeurs`
  ADD PRIMARY KEY (`id_demandeurs`);

--
-- Index pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  ADD PRIMARY KEY (`id_fournisseurs`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `demandeurs`
--
ALTER TABLE `demandeurs`
  MODIFY `id_demandeurs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `fournisseurs`
--
ALTER TABLE `fournisseurs`
  MODIFY `id_fournisseurs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
