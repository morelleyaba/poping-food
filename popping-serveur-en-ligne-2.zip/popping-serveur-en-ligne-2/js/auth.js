

      $(document).ready(function(){

// ********traitement de recherche de la page fournisseur.php
	$("#send").on("click", function(e){
		e.preventDefault();
		var form = $("#form-depot");
    // recuperer le name de l'attribut send du formulaire de 
   var valeurSubmit=$('#send').attr('name');
		$.ajax({

           method: "POST",
           url:"trait_fournisseurs.php",
           dataType:"JSON",
           data: form.serialize()+ '&submit='+ valeurSubmit,
           success: function(reponse)
           {
           	if (reponse.msg=='ok1') {
             
        //display the modal contain picture upload
             $("#getCodeModal").modal("show");

        // $("#getCode").html(reponse.msg).show();  
            }
             else{

                 $('#message').addClass("alert alert-danger").html(reponse.msg);

                 
            }
           },

           error: function () {
				alert("Erreur d'envoi de donnée");
			}
		})
	});


// ********traitement du modal fournisseur.php


  $("#fsend").on("click", function(e){
    e.preventDefault();
    var form = $("#form-depot");
    // recuperer le name de l'attribut fsend
   var valeurSubmit=$('#fsend').attr('name');
    // ***********************************************************************
    
    var formdata = new FormData(form[0]);
    formdata.append("file", $('#pictures')); 
    

    $.ajax({
      method: "POST",
      enctype: 'multipart/form-data',// type d'encodage 
      url: "trait.php",
      processData: false,
          contentType: false,
          cache: false,
      dataType: "JSON",
     
      data: formdata,
      success: function(data)
      {
        if (data.msg2=="ok") {
          $("#message").removeClass("alert-danger").addClass("alert alert-success").html('l\'enregistrement a été effectué avec succes');
          $("#form-depot").trigger('reset');
          $("#pic-upload").removeClass("alert-danger").html('<B> Ajouter une image de description svp</B>');
           $("#getCodeModal").modal("hide");
        }else{
          $("#pic-upload").addClass("alert alert-danger").html(data.msg2);
         
        }
      },
      error: function () {
        alert("Erreur d'envoi de donnée");
      }
    })
 
// **********************************************************
  });




// ****** traitement demadeurs.php

     
  $("#form-ask").on("submit", function(e){
    
    e.preventDefault();
    var form = $("#form-ask");

    $.ajax({

           method: "POST",
           url:"trait_demandeurs.php",
           dataType:"JSON",
           data: form.serialize(),
           success: function(reponse)
           {
            if (reponse.msg=='ok') {
             
        $("#message").removeClass("alert-danger").addClass("alert alert-success").html('l\'enregistrement a été effectué avec succes!!');
             $("#form-ask").trigger('reset');
            

            
            }

            else{

                 $('#message').addClass("alert alert-danger").html(reponse.msg);

            }
           },

           error: function () {
        alert("Erreur d'envoi de donnée");
      }
    })
  });
})
